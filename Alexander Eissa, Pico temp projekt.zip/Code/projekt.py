import time
import machine
import onewire, ds18x20
import ujson

with open("config.json", "r") as f:
    config = ujson.load(f)

dat_pin_number = config.get(
    "pin", 16
)  # Läser pinsen
sleep_time = config.get(
    "interval", 9
)  # läser pinsen intervaller

# Kopplar GPIO16
dat = machine.Pin(dat_pin_number)

# skapar ett obeject
ds = ds18x20.DS18X20(onewire.OneWire(dat))


# skannar
roms = ds.scan()
print("found devices:", roms)

# lsäer in ID från andra enheter
id = ""
for b in machine.unique_id():
    id += "{:02x}".format(b)


# loop
while True:
    ds.convert_temp()
    time.sleep(sleep_time)
    for rom in roms:
        sensor_id = hex(int.from_bytes(rom, "little"))[2:]
        print()